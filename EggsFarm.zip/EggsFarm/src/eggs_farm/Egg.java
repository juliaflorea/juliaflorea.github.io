package eggs_farm;

import java.io.Serializable;

public class Egg implements Serializable {
	int serial; // serial number for egg
	int Hen_serial; // serial number for hen

	public Egg(int Hen_serial, int serial) {
		this.Hen_serial = Hen_serial; // initialising the parameters of the constructor
		this.serial = serial;
	}

}
