package eggs_farm;

public class Main {
	

	public static void main(String[] args) {
		

		FarmHeadquarters F = new FarmHeadquarters();
		F.start();

	}
}
