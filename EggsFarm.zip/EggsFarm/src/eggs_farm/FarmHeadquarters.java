package eggs_farm;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.net.*;
import java.util.Vector;

public class FarmHeadquarters extends Thread {

	// we create the lists of farms, employees and eggs
	Vector<Farm> farms = new Vector<Farm>();
	Vector<Employee> employees = new Vector<Employee>();
	Vector<Egg> eggs = new Vector<Egg>();
	ServerSocket socket = null;
	int active_farms; // the farms which produce eggs
	static int no_hens = 0;

	FarmHeadquarters() {
		active_farms = 3; // we create the farms(a random number between 2 and 5)
		for (int i = 0; i < 3; i++) {
			farms.add(new Farm(this, i));
		}
		openTransportLine();

		// the maximum number of employees
		for (int i = 0; i < 10; i++) {
			employees.add(new Employee(this, farms));
			System.out.println("The employee" + i + " was called for duty.");
		}
		System.out.println("The case is running.");
	}

	public void run() {
		while (farmsRunning()) {
			addHens(); // we add the hens at a random moment of time, while the farms are active and
						// working

			try {
				Thread.sleep((int) (Math.random() * (1000 - 500) + 500));
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		System.out.println("All farms have finished their work, having a total of " + eggs.size()
				+ " eggs, which have been delivered to the farm headquarters. ");
		try {
			socket.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	private void openTransportLine() { // function to create new thread for the transport line of the eggs
		try {
			socket = new ServerSocket(7777);
			new Thread(() -> { // new thread to take care of the transport line
				accepteggs();
			}).start();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void accepteggs() { // function to accept the eggs received by the farms, which were transported by
								// the employees
		while (farmsRunning()) { // while the farms are working
			Socket employees_transport = null;
			try {
				employees_transport = socket.accept();
				// making a connection in order to transport the eggs
				InputStream inputStream = employees_transport.getInputStream();
				ObjectInputStream objectInputStream = new ObjectInputStream(inputStream);

				try {
					System.out.println("The egg was received.");
					// the confirmation that the egg was received by the farm
					Egg egg = (Egg) objectInputStream.readObject();
					eggs.add(egg);
				} catch (ClassNotFoundException e) {

					e.printStackTrace();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
			try {
				if (employees_transport != null)
					// if a connection had been made,the socket closes
					employees_transport.close();
			} catch (IOException e) {
				e.printStackTrace();
			}

		}
	}

	private synchronized void addHens() { // function to add hens to each farm
		for (int i = 0; i < farms.size(); i++) {
			if (farms.elementAt(i).needsHens())
				farms.elementAt(i).addHen(new Hen(no_hens++));
		}
	}

	public void announce(Farm F) { // function to announce the employees that the a certain farm has eggs ready to
									// be
									// transported
		for (int i = 0; i < employees.size(); i++) {
			if (employees.elementAt(i).announce(F)) {
			}
		}
	}

	public synchronized void announceStop(Farm Farm) {
		// function called by the farms which stop the production of the eggs
		active_farms--;
	}

	public boolean farmsRunning() {
		// function to check if there are farms which are working (producing eggs)
		if (active_farms == 0)
			return false;
		return true;
	}

}
