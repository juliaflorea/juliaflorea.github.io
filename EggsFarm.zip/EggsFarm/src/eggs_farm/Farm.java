package eggs_farm;

import java.util.Vector;
import java.util.concurrent.Semaphore;
import java.util.concurrent.locks.ReentrantLock;

public class Farm extends Thread {

	ReentrantLock move_lock = new ReentrantLock(true);
	FarmHeadquarters FarmHeadquarters = null;
	Vector<Hen> hens = new Vector<Hen>();
	Vector<Egg> eggs = new Vector<Egg>();
	Semaphore semaphore = new Semaphore(10, true);
	int grid_size = 0;
	int[][] grid; // the farm is a matrix N x N of random size between 100 and 500
	int code; // the code/ number for identifying a certain farm
	int no_eggs_created = 0;
	int no_egg_needed;

	public Farm(FarmHeadquarters farmHeadquarters, int code) {
		this.FarmHeadquarters = FarmHeadquarters;
		grid_size = (int) (Math.random() * (500 - 100) + 100);
		grid = new int[grid_size][grid_size];
		this.code = code;
		no_egg_needed = (int) (Math.random() * (100 - 25) + 25);
		// number of eggs needed in each farm
		new Thread(() -> { // a new thread for handling the position request
			RequestPositions();
		}).start();

		this.start();
	}

	public void run() {
		while (FarmRunning()) { // announces if there are enough eggs to be transported
			if (eggs.size() > 9) {
				FarmHeadquarters.announce(this);
			}

		}
		stopHens(); // enough eggs were produced, so the hens can rest
		while (!eggs.isEmpty()) { // while there are enough eggs for a transport, we announce the farm
									// headquarters and we can empty the eggs list
			FarmHeadquarters.announce(this);

		}
		FarmHeadquarters.announceStop(this); // announce that a certain farm has stopped the production
		System.out.println("The farm " + code + " has finished producing the necessary eggs.");

	}

	public void addHen(Hen production_hen) {
		// function to add a hen from the farm headquarters on our grid ( farm)
		int x; // x and y represent the coordinates for the position matrix
		int y;
		move_lock.lock(); // we have a lock until the hen has been placed
		do { // we generate some random position for the hens
			x = (int) ((Math.random() * (grid_size)) + 0);
			y = (int) ((Math.random() * (grid_size)) + 0);
		} while (grid[x][y] != 0);
		grid[x][y] = 1;
		move_lock.unlock();
		production_hen.Assign(this, x, y);
		hens.add(production_hen);
		production_hen.start();
		System.out.println("The hen " + "code" + " is producing eggs on the position" + x + ", " + y);
	}

	public void RequestMove() { // function to request a move
		move_lock.lock();
	}

	public boolean RequestMoveDirection(int x, int y, int i) {
		int val = -1; // function to check if the direction which the hen chooses is available
		switch (i) {
		case 0:
			if (x + 1 >= grid_size)
				break;
			val = grid[x + 1][y];
			break;
		case 1: // the function is not synchronized because the hen locks the lock before
				// calling it
			if (x - 1 < 0)
				break; // this is done in order to make sure that a hen which wants to move can check
						// each possible direction before deciding that it can't move a certain way
		case 2: // if the function had been synchronized,
			if (y + 1 >= grid_size) // more hens would have been able to enter the moving stage without actually
									// being able to move
				break; // if their first choice had not been available, the hens would have been
						// blocked
			val = grid[x][y + 1];
			break;
		case 3:
			if (y - 1 < 0)
				break;
			val = grid[x][y - 1];
			break;
		}
		// we check if the direction is available and then move the hen
		if (val == 0) {
			switch (i) {
			case 0:
				grid[x + 1][y]++;
				break;
			case 1:
				grid[x - 1][y]++;
				break;
			case 2:
				grid[x][y + 1]++;
				break;
			case 3:
				grid[x][y - 1]++;
				break;
			}
			grid[x][y]--;
			return true;
		}
		return false;
	}

	public void MoveFinished() { // function to unlock the lock when after the hens were moved

		move_lock.unlock();

	}

	public void TransferEgg(Egg egg) { // function to transfer the eggs to the farms
		move_lock.lock();
		eggs.add(egg);
		no_eggs_created++;
		move_lock.unlock();
		System.out.println("Egg produced in the farm " + code);
	}

	public void RequestPositions() {
		// function to request the position
		while (FarmRunning()) {
			try {
				move_lock.lock();
				for (int i = 0; i < hens.size(); i++) {
					hens.elementAt(i).GetPosition();
				}
			} finally {
				move_lock.unlock();
			}
			try { // sleep for a random time to check the position
				sleep((int) (Math.random() * (5000 - 1000) + 1000));
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	private boolean FarmRunning() { // function to check if the farm is working properly

		return no_egg_needed > no_eggs_created;
	}

	public boolean needsHens() { // function to check if the farm needs more hens
		return hens.size() < grid_size / 2 && FarmRunning();
		// checks if the number of hens is less than N/2 and if the farm needs more eggs
	}

	public int getCode() {
		return code; // function to return to code of the farm
	}

	public int getNoEggs() {
		// function used by the employees in order to find out the number of eggs
		return eggs.size();
	}

	public Vector<Egg> getEggList() {
		// function used by the employees in order to see the list of the eggs
		return eggs;
	}

	private void stopHens() {
		// function to stop the hens from producing eggs
		for (int i = 0; i < hens.size(); i++) {
			hens.elementAt(i).stopProduction();
		}
	}

	public boolean RequestTransportAccess() {
		// function used by the employees to find out the information of the transports
		return semaphore.tryAcquire();
	}

	public void TransportFinished() {
		// function to announce that the transport has been finished
		semaphore.release();
	}

}
