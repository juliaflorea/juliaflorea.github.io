package eggs_farm;

import java.util.Random;

public class Hen extends Thread {
	int x; // x and y compose the coordinates for the position of the eggs based on the
			// direction chosen by the hen
	int y;
	private Farm Farm = null;
	boolean necessaryEggs;
	private final int serial; // serial number of the hen
	int[] MoveDirection = null; // matrix with 4 directions (left, right, up, down) having a random order

	Hen(int serial) {
		this.serial = serial;
		necessaryEggs = true;
		MoveDirection = new int[4];
		MoveDirection[0] = 0;
		MoveDirection[1] = 1;
		MoveDirection[2] = 2;
		MoveDirection[3] = 3;
	}

	public void Assign(Farm Farm, int x, int y) { // function to assign hens to the farms in a random place
		this.Farm = Farm;
		this.x = x;
		this.y = y;
	}

	public void run() {
		boolean moved;
		while (necessaryEggs) {
			moved = tryToMove(); // while there are necessary eggs for the farm, the hen tries to move in a
									// certain direction
			if (moved) {
				Egg egg = new Egg(Farm.getCode(), this.serial);
				Farm.TransferEgg(egg); // if the hen was able to move and it laid an egg, then we create the egg and
										// transfer it to the farm
				System.out.println("The egg has been created.");
				if (moved) {
					try {
						sleep(30 * 10); // after laying an egg, the hen has to rest before laying another one

					} catch (InterruptedException e) { // if the egg was produced, then the hen can go ahead and produce
														// another one as long as it is alive
						e.printStackTrace();
					}
				} else {
					try { // if the hen is surrounded by other hens and can't move in any direction
						sleep((int) (Math.random() * (50 - 10) + 10)); // it waits for a random time until it can move
																		// again
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}

			}
		}
	}

	private boolean tryToMove() {
		randomizeDirections(); // randomizes the directions of the matrix where hens can move
		boolean moved = false;
		try {
			Farm.RequestMove(); // there exists a lock, so in order to make a move, we have to send a request
			for (int i = 0; i < 4; i++) { // the hen tries to move in the 4 possible directions
				if (Farm.RequestMoveDirection(x, y, MoveDirection[i])) {
					Move(MoveDirection[i]);
					moved = true;
					System.out.println("The hen " + serial + " on the position " + this.x + ", " + this.y
							+ " has created one more egg.");
					break;
				}

			}
		} finally {
			Farm.MoveFinished(); // unlocking the lock
		}
		return moved;
	}

	private void Move(int i) { // function to update the coordinates for the position of the egg based on the
								// direction
								// which the hen chooses
		switch (i) {
		case 0:
			x++;
			break;
		case 1:
			x--;
			break;
		case 2:
			y++;
			break;
		case 3:
			y--;
			break;
		}

	}

	public int GetPosition() {
		return x * 1000 + y; // function to get the position of the eggs
		// the leftmost numbers are represented by x and the rightmost ones by y
	}

	public void stopProduction() { // function to update the necessaryEggs variable to false, in order to stop the
									// production
									// because eggs are no longer needed
		necessaryEggs = false;
		System.out.println("The hen " + serial + "stopped laying eggs.");

	}

	private void randomizeDirections() { // function to randomize the direction of the matrix
		Random rand = new Random();
		for (int i = 0; i < MoveDirection.length; i++) {
			int randomIndexToSwap = rand.nextInt(MoveDirection.length);
			int temp = MoveDirection[randomIndexToSwap];
			MoveDirection[randomIndexToSwap] = MoveDirection[i];
			MoveDirection[i] = temp;
		}

	}

}
