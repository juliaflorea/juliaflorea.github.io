package eggs_farm;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.Vector;

public class Employee extends Thread {

	FarmHeadquarters FarmHeadquarters = null;
	private Vector<Farm> farms = null;
	private volatile Farm source_Farm = null; // the source farm is declared volatile in order to be sure that the
												// variable is up to date and thread safe
	Socket socket = null;

	public Employee(FarmHeadquarters FarmHeadquarters, Vector<Farm> farms) {
		this.FarmHeadquarters = FarmHeadquarters;
		this.farms = farms; // this class must have access to the farms in order to be able to read the data
		this.start();
	}

	public void run() {
		while (FarmHeadquarters.farmsRunning()) {
			readData(); // reads the information from the monitoring system of the farm headquarters
			if (getSourceFarm() != null) { // when a farm is assigned to retrieve an egg, it completes the task
				transportEggs();
			}
			setSource(null); // resets the source_Farm
		}
	}

	private void transportEggs() {
		// function to transport the eggs to the farm
		if (source_Farm.RequestTransportAccess()) { // the source farm requests the access to the system
			source_Farm.RequestMove(); // is locked
			Vector<Egg> V = source_Farm.getEggList();
			// the source farm receives the list of the eggs
			if (V.isEmpty()) {
				// if there are no more eggs, release the lock
				source_Farm.MoveFinished();
				source_Farm.TransportFinished();
				return;
			}
			Egg egg = V.remove(0); // places the first egg in the list; releases the lock and permits access
			source_Farm.MoveFinished();
			source_Farm.TransportFinished();

			try {
				socket = new Socket("localhost", 7777);
				OutputStream outputStream = socket.getOutputStream();
				// gets the output stream directly from the socket
				ObjectOutputStream objectOutputStream = new ObjectOutputStream(outputStream);
				objectOutputStream.writeObject(egg);
				// creates an output stream object in order to send an object through it
				socket.close();
			} catch (IOException e) {
				// e.printStackTrace();
			}
			System.out.println("The egg has been sent to the farm headquarters by the employees.");
		}
	}

	private void readData() {
		// function to read the information from the farm monitoring system and wait
		// after each reading
		for (int i = 0; i < farms.size(); i++) {
			farms.elementAt(i).getNoEggs();
			farms.elementAt(i).getEggList();
			try {
				sleep((int) (Math.random() * (30 - 10) + 10)); // waiting time
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	public boolean announce(Farm F) {
		// function to announce the farm if an egg does not have a source of transport
		// and assign one to it
		if (source_Farm == null) {
			setSource(F);
			return true;
		}
		return false;
	}

	private synchronized void setSource(Farm F) {
		// function to set the source to the farm; it is synchronized
		// because it can be called by any case through announce or through Hen in a
		// loop
		source_Farm = F;
	}

	private Farm getSourceFarm() {
		return source_Farm; // function to return the source farm of an egg
	}

}
